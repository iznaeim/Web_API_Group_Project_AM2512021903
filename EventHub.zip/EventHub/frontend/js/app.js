// EventHub frontend: shared helpers.
// Frontend lives in EventHub/frontend, API in EventHub/backend/api (same origin, so the PHP session cookie works).
const API = '../backend/api/';

// ---- Logged-in user (display only; the real session is the PHP cookie) ----
const Auth = {
  user() { try { return JSON.parse(localStorage.getItem('eh_user')); } catch { return null; } },
  save(u) { localStorage.setItem('eh_user', JSON.stringify(u)); },
  clear() { localStorage.removeItem('eh_user'); },
  // Redirect to login unless a user with one of the allowed roles is signed in
  require(roles) {
    const u = Auth.user();
    if (!u) { location.href = 'auth.html'; return null; }
    if (roles && !roles.includes(u.role)) { location.href = 'index.html'; return null; }
    return u;
  }
};

// ---- API wrapper ----
async function api(file, { method = 'GET', query, body } = {}) {
  const qs = query ? '?' + new URLSearchParams(query) : '';
  let res;
  try {
    res = await fetch(API + file + qs, {
      method,
      headers: body ? { 'Content-Type': 'application/json' } : {},
      body: body ? JSON.stringify(body) : undefined,
      credentials: 'same-origin'
    });
  } catch { throw new Error('Cannot reach the server. Is Apache running in XAMPP?'); }
  const data = await res.json().catch(() => ({
    success: false,
    message: `Server sent an invalid response (${res.status}). Check the PHP error log and the database name in config/database.php.`
  }));
  if (res.status === 401) Auth.clear();            // session expired
  if (!res.ok || data.success === false) throw new Error(data.message || `Request failed (${res.status})`);
  return data;
}

// ---- Helpers ----
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = n => 'RM ' + Number(n).toFixed(2);
const parseDate = d => new Date(String(d).replace(' ', 'T'));
const fmtDate = d => parseDate(d).toLocaleString('en-MY', { dateStyle: 'medium', timeStyle: 'short' });
const stars = n => '★'.repeat(Math.round(n)) + '☆'.repeat(5 - Math.round(n));

function toast(msg, ok = true) {
  let t = $('toast');
  if (!t) { t = document.createElement('div'); t.id = 'toast'; document.body.appendChild(t); }
  t.textContent = msg; t.className = ok ? 'ok' : 'bad'; t.style.display = 'block';
  clearTimeout(t._h); t._h = setTimeout(() => t.style.display = 'none', 3500);
}

function renderNav() {
  const u = Auth.user();
  const staff = u && ['admin', 'organiser'].includes(u.role);
  $('nav').innerHTML = `
    <a class="logo" href="index.html"><span class="logo-mark">◆</span>EventHub</a>
    <button class="burger" id="menuBtn" aria-label="Menu" aria-expanded="false"><span></span><span></span><span></span></button>
    <nav id="menu">
      <a href="index.html">Events</a>
      ${u ? `<a href="bookings.html">${u.role === 'customer' ? 'My Bookings' : 'Bookings'}</a>` : ''}
      ${u && u.role === 'customer' ? `<a href="reviews.html">My Reviews</a>` : ''}
      ${staff ? `<a href="manage.html">Manage</a>` : ''}
      ${u ? `<span class="muted">${esc(u.name)} (${esc(u.role)})</span><button class="small ghost" id="logout">Logout</button>`
          : `<a class="btn small" href="auth.html">Login / Register</a>`}
    </nav>`;
  $('menuBtn').onclick = () => {
    const open = $('nav').classList.toggle('open');
    $('menuBtn').setAttribute('aria-expanded', open);
  };
  const here = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('#menu a:not(.btn)').forEach(a => { if (a.getAttribute('href') === here) a.classList.add('active'); });
  const onScroll = () => $('nav').classList.toggle('scrolled', scrollY > 8);
  addEventListener('scroll', onScroll, { passive: true }); onScroll();
  const b = $('logout');
  if (b) b.onclick = async () => {
    try { await api('logout.php', { method: 'POST' }); } catch {}
    Auth.clear(); location.href = 'auth.html';
  };
}

// Load all venues once, returns {id: venue}
async function loadVenueMap() {
  const res = await api('venues.php');
  const map = {}; res.data.forEach(v => map[v.venue_id] = v);
  return { list: res.data, map };
}